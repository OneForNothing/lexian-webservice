package cose.lexian.util;

public class GoodsException extends Exception {
    public GoodsException() {
    }

    public GoodsException(String message) {
        super(message);
    }
}
