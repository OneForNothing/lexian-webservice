package cose.lexian.util;

public class TypeException extends Exception {
    public TypeException() {
        super();
    }

    public TypeException(String message) {
        super(message);
    }
}
