# lexian-webservice
乐鲜商城服务端－JAVA
> 本项目起始于2018年8月20日,服务于18-19-1学期实训，为lexian-mall的后端部分
